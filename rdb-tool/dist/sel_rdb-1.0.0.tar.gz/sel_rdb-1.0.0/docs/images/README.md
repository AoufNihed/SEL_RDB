# SEL Logo Placeholder

This directory should contain the SEL Schweitzer Engineering Laboratories logo file:
- sel_logo.png

The logo would be displayed at the top of the README.md file.

Please obtain the official SEL logo from Schweitzer Engineering Laboratories for proper use.